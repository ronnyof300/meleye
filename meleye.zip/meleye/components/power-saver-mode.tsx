"use client"

import { useState, useEffect } from "react"
import { BatteryIcon, BatteryLowIcon, SunIcon } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export function PowerSaverMode() {
  const [powerSaverEnabled, setPowerSaverEnabled] = useState(false)
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null)
  const [isCharging, setIsCharging] = useState<boolean | null>(null)

  useEffect(() => {
    // Check if Battery API is supported
    if ("getBattery" in navigator) {
      const getBatteryInfo = async () => {
        try {
          // @ts-ignore - getBattery is not in the standard navigator type
          const battery = await navigator.getBattery()

          // Update initial state
          setBatteryLevel(battery.level * 100)
          setIsCharging(battery.charging)

          // Set up event listeners
          battery.addEventListener("levelchange", () => {
            setBatteryLevel(battery.level * 100)

            // Auto-enable power saver mode if battery is below 20%
            if (battery.level < 0.2 && !powerSaverEnabled) {
              setPowerSaverEnabled(true)
            }
          })

          battery.addEventListener("chargingchange", () => {
            setIsCharging(battery.charging)

            // Auto-disable power saver mode if charging
            if (battery.charging && powerSaverEnabled) {
              setPowerSaverEnabled(false)
            }
          })
        } catch (error) {
          console.error("Battery API error:", error)
        }
      }

      getBatteryInfo()
    }
  }, [powerSaverEnabled])

  // Apply power saving measures when enabled
  useEffect(() => {
    if (powerSaverEnabled) {
      // Reduce animation
      document.body.classList.add("power-saver")

      // Lower video quality for camera
      const videoElements = document.querySelectorAll("video")
      videoElements.forEach((video) => {
        if (video.srcObject instanceof MediaStream) {
          const tracks = video.srcObject.getVideoTracks()
          tracks.forEach((track) => {
            const capabilities = track.getCapabilities()
            if (capabilities.width && capabilities.height) {
              track
                .applyConstraints({
                  width: { ideal: 640 },
                  height: { ideal: 480 },
                })
                .catch((e) => console.error("Could not apply video constraints:", e))
            }
          })
        }
      })
    } else {
      // Restore normal operation
      document.body.classList.remove("power-saver")
    }

    return () => {
      document.body.classList.remove("power-saver")
    }
  }, [powerSaverEnabled])

  return (
    <div className="flex items-center justify-between p-2 bg-muted/50 rounded-lg">
      <div className="flex items-center gap-2">
        {isCharging ? (
          <SunIcon className="h-4 w-4 text-yellow-500" />
        ) : batteryLevel && batteryLevel < 20 ? (
          <BatteryLowIcon className="h-4 w-4 text-red-500" />
        ) : (
          <BatteryIcon className="h-4 w-4" />
        )}

        <div className="text-sm">
          {batteryLevel !== null ? (
            <span>
              Battery: {Math.round(batteryLevel)}%{isCharging && " (Charging)"}
            </span>
          ) : (
            <span>Power Saver</span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Switch id="power-saver" checked={powerSaverEnabled} onCheckedChange={setPowerSaverEnabled} />
        <Label htmlFor="power-saver" className="text-sm">
          Power Saver Mode
        </Label>
      </div>
    </div>
  )
}
