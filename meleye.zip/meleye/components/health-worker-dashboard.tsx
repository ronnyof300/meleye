"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircleIcon,
  ClockIcon,
  SearchIcon,
  UserIcon,
  MapPinIcon,
  PhoneIcon,
  MessageSquareIcon,
} from "lucide-react"

// Mock data for demonstration
const mockCases = [
  {
    id: "case-001",
    patientName: "Amara Okafor",
    location: "Lagos, Nigeria",
    condition: "Conjunctivitis",
    severity: "medium",
    date: "2023-06-15",
    status: "pending",
    phone: "+234 812 345 6789",
    notes: "Patient reported redness and itching in both eyes for 3 days.",
  },
  {
    id: "case-002",
    patientName: "Kwame Mensah",
    location: "Accra, Ghana",
    condition: "Eczema",
    severity: "medium",
    date: "2023-06-14",
    status: "in-progress",
    phone: "+233 24 123 4567",
    notes: "Follow-up appointment scheduled for next week. Prescribed hydrocortisone cream.",
  },
  {
    id: "case-003",
    patientName: "Fatima Ahmed",
    location: "Nairobi, Kenya",
    condition: "Trachoma",
    severity: "high",
    date: "2023-06-13",
    status: "resolved",
    phone: "+254 712 345 678",
    notes: "Referred to specialist. Antibiotics prescribed. Follow-up in 2 weeks.",
  },
  {
    id: "case-004",
    patientName: "Tendai Moyo",
    location: "Harare, Zimbabwe",
    condition: "Psoriasis",
    severity: "high",
    date: "2023-06-12",
    status: "pending",
    phone: "+263 77 123 4567",
    notes: "First-time diagnosis. Patient needs education on condition management.",
  },
  {
    id: "case-005",
    patientName: "Aisha Diallo",
    location: "Dakar, Senegal",
    condition: "Vitiligo",
    severity: "low",
    date: "2023-06-10",
    status: "in-progress",
    phone: "+221 77 123 45 67",
    notes: "Patient concerned about social stigma. Providing counseling and treatment options.",
  },
]

export function HealthWorkerDashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [selectedCase, setSelectedCase] = useState<(typeof mockCases)[0] | null>(null)

  // Filter cases based on search term and active tab
  const filteredCases = mockCases.filter((c) => {
    const matchesSearch =
      c.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.condition.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.location.toLowerCase().includes(searchTerm.toLowerCase())

    if (activeTab === "all") return matchesSearch
    return matchesSearch && c.status === activeTab
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "in-progress":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "resolved":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "low":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "high":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
    }
  }

  const handleStatusChange = (caseId: string, newStatus: string) => {
    // In a real app, this would update the database
    console.log(`Changing case ${caseId} status to ${newStatus}`)

    // For demo purposes, we'll just close the case detail view
    setSelectedCase(null)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Community Health Worker Portal</CardTitle>
          <CardDescription>Manage patient referrals and follow-ups</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search patients, conditions, or locations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">Export Data</Button>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-4 mb-6">
              <TabsTrigger value="all">All Cases</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="in-progress">In Progress</TabsTrigger>
              <TabsTrigger value="resolved">Resolved</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-0">
              {filteredCases.length === 0 ? (
                <div className="text-center py-10">
                  <p className="text-muted-foreground">No cases found matching your criteria.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredCases.map((caseItem) => (
                    <Card
                      key={caseItem.id}
                      className="cursor-pointer hover:bg-muted/50 transition-colors"
                      onClick={() => setSelectedCase(caseItem)}
                    >
                      <CardContent className="p-4">
                        <div className="flex flex-col md:flex-row justify-between gap-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <UserIcon className="h-4 w-4 text-muted-foreground" />
                              <h3 className="font-medium">{caseItem.patientName}</h3>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPinIcon className="h-4 w-4 text-muted-foreground" />
                              <p className="text-sm text-muted-foreground">{caseItem.location}</p>
                            </div>
                          </div>

                          <div className="space-y-1">
                            <div className="flex items-center gap-2 justify-end">
                              <Badge className={getSeverityColor(caseItem.severity)}>
                                {caseItem.severity.charAt(0).toUpperCase() + caseItem.severity.slice(1)}
                              </Badge>
                              <Badge>{caseItem.condition}</Badge>
                            </div>
                            <div className="flex items-center gap-2 justify-end">
                              <Badge className={getStatusColor(caseItem.status)}>
                                {caseItem.status === "in-progress"
                                  ? "In Progress"
                                  : caseItem.status.charAt(0).toUpperCase() + caseItem.status.slice(1)}
                              </Badge>
                              <span className="text-xs text-muted-foreground">{caseItem.date}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {selectedCase && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>{selectedCase.patientName}</CardTitle>
                <CardDescription>
                  {selectedCase.condition} - {selectedCase.date}
                </CardDescription>
              </div>
              <Badge className={getStatusColor(selectedCase.status)}>
                {selectedCase.status === "in-progress"
                  ? "In Progress"
                  : selectedCase.status.charAt(0).toUpperCase() + selectedCase.status.slice(1)}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <MapPinIcon className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedCase.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <PhoneIcon className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedCase.phone}</span>
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-1">Condition Details</h4>
                <div className="flex gap-2 mb-2">
                  <Badge className={getSeverityColor(selectedCase.severity)}>
                    {selectedCase.severity.charAt(0).toUpperCase() + selectedCase.severity.slice(1)} Severity
                  </Badge>
                </div>
                <p className="text-sm">{selectedCase.notes}</p>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-2">Case Notes</h4>
              <textarea className="w-full min-h-[100px] p-2 border rounded-md" placeholder="Add your notes here..." />
            </div>
          </CardContent>
          <CardFooter className="flex flex-wrap gap-2">
            <Button
              onClick={() => handleStatusChange(selectedCase.id, "resolved")}
              className="bg-green-600 hover:bg-green-700"
            >
              <CheckCircleIcon className="mr-2 h-4 w-4" />
              Mark as Resolved
            </Button>
            <Button onClick={() => handleStatusChange(selectedCase.id, "in-progress")} variant="outline">
              <ClockIcon className="mr-2 h-4 w-4" />
              Mark In Progress
            </Button>
            <Button variant="outline">
              <MessageSquareIcon className="mr-2 h-4 w-4" />
              Send Message
            </Button>
            <Button variant="outline" onClick={() => setSelectedCase(null)}>
              Close
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}
