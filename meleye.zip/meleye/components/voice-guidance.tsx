"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { VolumeIcon, Volume2Icon, VolumeXIcon } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type VoiceGuidanceProps = {
  instructions: string
  currentStep?: string
}

type VoiceLanguage = {
  code: string
  name: string
  voice: string
}

const availableLanguages: VoiceLanguage[] = [
  { code: "en", name: "English", voice: "en-US" },
  { code: "sw", name: "Swahili", voice: "sw-KE" },
  { code: "ha", name: "Hausa", voice: "ha" },
  { code: "yo", name: "Yoruba", voice: "yo" },
  { code: "am", name: "Amharic", voice: "am-ET" },
]

export function VoiceGuidance({ instructions, currentStep }: VoiceGuidanceProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [selectedLanguage, setSelectedLanguage] = useState<VoiceLanguage>(availableLanguages[0])
  const speechSynthRef = useRef<SpeechSynthesisUtterance | null>(null)

  const speakText = (text: string) => {
    // Stop any current speech
    window.speechSynthesis.cancel()

    if (isMuted) return

    // Create a new utterance
    const utterance = new SpeechSynthesisUtterance(text)

    // Try to find a voice that matches the selected language
    const voices = window.speechSynthesis.getVoices()
    const voice = voices.find((v) => v.lang.startsWith(selectedLanguage.code))

    if (voice) {
      utterance.voice = voice
    }

    // Set other properties
    utterance.rate = 0.9
    utterance.pitch = 1

    // Store reference to stop later if needed
    speechSynthRef.current = utterance

    // Start speaking
    window.speechSynthesis.speak(utterance)
    setIsPlaying(true)

    // Update state when finished
    utterance.onend = () => {
      setIsPlaying(false)
      speechSynthRef.current = null
    }
  }

  const togglePlay = () => {
    if (isPlaying) {
      window.speechSynthesis.cancel()
      setIsPlaying(false)
    } else {
      speakText(instructions)
    }
  }

  const toggleMute = () => {
    if (!isMuted && isPlaying) {
      window.speechSynthesis.cancel()
      setIsPlaying(false)
    }

    setIsMuted(!isMuted)
  }

  const handleLanguageChange = (code: string) => {
    const language = availableLanguages.find((lang) => lang.code === code) || availableLanguages[0]
    setSelectedLanguage(language)

    // If currently playing, restart with new language
    if (isPlaying) {
      window.speechSynthesis.cancel()
      setTimeout(() => speakText(instructions), 100)
    }
  }

  return (
    <div className="flex items-center gap-2 mt-2">
      <Button
        variant="outline"
        size="icon"
        onClick={togglePlay}
        aria-label={isPlaying ? "Pause voice guidance" : "Play voice guidance"}
      >
        {isPlaying ? <VolumeIcon className="h-4 w-4" /> : <Volume2Icon className="h-4 w-4" />}
      </Button>

      <Button variant="outline" size="icon" onClick={toggleMute} aria-label={isMuted ? "Unmute" : "Mute"}>
        {isMuted ? <VolumeXIcon className="h-4 w-4" /> : <VolumeIcon className="h-4 w-4" />}
      </Button>

      <Select value={selectedLanguage.code} onValueChange={handleLanguageChange}>
        <SelectTrigger className="w-[120px]">
          <SelectValue placeholder="Language" />
        </SelectTrigger>
        <SelectContent>
          {availableLanguages.map((language) => (
            <SelectItem key={language.code} value={language.code}>
              {language.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {currentStep && <span className="text-sm text-muted-foreground ml-2">Current step: {currentStep}</span>}
    </div>
  )
}
