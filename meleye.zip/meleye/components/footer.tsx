import Link from "next/link"

export function Footer() {
  return (
    <footer className="w-full border-t py-6 md:py-8">
      <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
        <div className="flex items-center gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-5 w-5 text-primary"
          >
            <path d="M9 9a3 3 0 1 1 5.12 2.12L9 16.24" />
            <circle cx="12" cy="12" r="9" />
          </svg>
          <span className="text-sm font-semibold">MelËye</span>
        </div>
        <nav className="flex gap-4 text-xs md:gap-6 md:text-sm">
          <Link href="/privacy" className="text-muted-foreground hover:underline">
            Privacy Policy
          </Link>
          <Link href="/terms" className="text-muted-foreground hover:underline">
            Terms of Service
          </Link>
          <Link href="/about" className="text-muted-foreground hover:underline">
            About
          </Link>
        </nav>
        <p className="text-xs text-muted-foreground md:text-sm">
          &copy; {new Date().getFullYear()} MelËye. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
