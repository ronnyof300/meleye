import type { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { HistoryList } from "@/components/history-list"

export const metadata: Metadata = {
  title: "Scan History - HealthScan",
  description: "View your previous health scans",
}

export default function HistoryPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8 md:py-12">
        <div className="mx-auto max-w-3xl">
          <h1 className="text-2xl font-bold mb-6 text-center">Scan History</h1>
          <HistoryList />
        </div>
      </main>
      <Footer />
    </div>
  )
}
