"use client"

import { useEffect, useState } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { WifiOffIcon, CheckCircleIcon } from "lucide-react"

export function OfflineBanner() {
  const [isOnline, setIsOnline] = useState(true)
  const [showBanner, setShowBanner] = useState(false)

  useEffect(() => {
    // Set initial state
    setIsOnline(navigator.onLine)

    // Add event listeners for online/offline events
    const handleOnline = () => {
      setIsOnline(true)
      setShowBanner(true)
      // Hide the "back online" banner after 3 seconds
      setTimeout(() => setShowBanner(false), 3000)
    }

    const handleOffline = () => {
      setIsOnline(false)
      setShowBanner(true)
    }

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  if (!showBanner) return null

  return (
    <Alert
      className={`fixed bottom-4 left-4 right-4 z-50 max-w-md mx-auto ${isOnline ? "bg-green-50 text-green-900 dark:bg-green-900 dark:text-green-50" : "bg-amber-50 text-amber-900 dark:bg-amber-900 dark:text-amber-50"}`}
    >
      {isOnline ? (
        <CheckCircleIcon className="h-4 w-4 text-green-600 dark:text-green-400" />
      ) : (
        <WifiOffIcon className="h-4 w-4 text-amber-600 dark:text-amber-400" />
      )}
      <AlertTitle>{isOnline ? "You're back online" : "You're offline"}</AlertTitle>
      <AlertDescription>
        {isOnline
          ? "Your connection has been restored. All features are now available."
          : "MelËye will continue to work with limited functionality. New scans will be saved locally and analyzed when you're back online."}
      </AlertDescription>
    </Alert>
  )
}
