"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/hooks/use-toast"
import { SendIcon } from "lucide-react"

type CommunityReferralProps = {
  condition: string
  severity: string
}

export function CommunityReferral({ condition, severity }: CommunityReferralProps) {
  const [location, setLocation] = useState("")
  const [message, setMessage] = useState("")
  const [loading, setLoading] = useState(false)
  const [region, setRegion] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Show success message
    toast({
      title: "Referral Sent",
      description: "A community health worker will contact you soon.",
    })

    setLoading(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Connect with a Community Health Worker</CardTitle>
        <CardDescription>
          Share your results with a local health worker who can provide guidance and support
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="region">Region</Label>
            <Select value={region} onValueChange={setRegion} required>
              <SelectTrigger id="region">
                <SelectValue placeholder="Select your region" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="eastern">Eastern Africa</SelectItem>
                <SelectItem value="western">Western Africa</SelectItem>
                <SelectItem value="northern">Northern Africa</SelectItem>
                <SelectItem value="central">Central Africa</SelectItem>
                <SelectItem value="southern">Southern Africa</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Your Location</Label>
            <Input
              id="location"
              placeholder="City/Town/Village"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Additional Information (Optional)</Label>
            <Textarea
              id="message"
              placeholder="Any additional symptoms or concerns..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={3}
            />
          </div>
        </form>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSubmit} disabled={loading || !region || !location} className="w-full">
          {loading ? (
            <>Processing...</>
          ) : (
            <>
              <SendIcon className="mr-2 h-4 w-4" />
              Connect with Health Worker
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
