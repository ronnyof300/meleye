import type { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ResultsDisplay } from "@/components/results-display"

export const metadata: Metadata = {
  title: "Scan Results - HealthScan",
  description: "View your health scan results and recommendations",
}

export default function ResultsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8 md:py-12">
        <div className="mx-auto max-w-2xl">
          <h1 className="text-2xl font-bold mb-6 text-center">Scan Results</h1>
          <ResultsDisplay />
        </div>
      </main>
      <Footer />
    </div>
  )
}
