// Simple offline storage utility for the app

// Save a scan to be processed later when online
export function saveOfflineScan(imageData: string): string {
  const scanId = `scan_${Date.now()}`
  const pendingScans = getPendingScans()

  pendingScans.push({
    id: scanId,
    imageData,
    timestamp: new Date().toISOString(),
  })

  localStorage.setItem("pendingScans", JSON.stringify(pendingScans))
  return scanId
}

// Get all pending scans
export function getPendingScans(): Array<{ id: string; imageData: string; timestamp: string }> {
  const storedScans = localStorage.getItem("pendingScans")
  return storedScans ? JSON.parse(storedScans) : []
}

// Process pending scans when back online
export async function processPendingScans(processFunction: (imageData: string) => Promise<any>): Promise<void> {
  const pendingScans = getPendingScans()

  if (pendingScans.length === 0) return

  // Process each scan
  const results = []
  for (const scan of pendingScans) {
    try {
      const result = await processFunction(scan.imageData)
      results.push({
        id: scan.id,
        result,
        success: true,
      })
    } catch (error) {
      results.push({
        id: scan.id,
        error,
        success: false,
      })
    }
  }

  // Clear pending scans
  localStorage.removeItem("pendingScans")

  // Store results
  localStorage.setItem("processedScans", JSON.stringify(results))

  return results
}

// Check if device is online
export function isOnline(): boolean {
  return navigator.onLine
}
