import type { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export const metadata: Metadata = {
  title: "About - MelËye",
  description: "Learn about MelËye AI health screening app",
}

export default function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8 md:py-12">
        <div className="mx-auto max-w-3xl">
          <h1 className="text-3xl font-bold mb-6">About MelËye</h1>

          <div className="space-y-6">
            <section>
              <h2 className="text-2xl font-semibold mb-3">Our Name</h2>
              <p className="text-muted-foreground">
                MelËye is derived from "Melanin" and "Eye" — a name that reflects our integrated approach to both skin
                and eye health. We created this platform specifically to address the bias in most AI systems that
                struggle to accurately detect conditions in people with darker skin tones. By focusing on the unique
                characteristics of African skin and eyes together, we're building technology that provides comprehensive
                health screening that truly serves everyone.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Our Mission</h2>
              <p className="text-muted-foreground">
                MelËye aims to make comprehensive health screening accessible to everyone across Africa. By leveraging
                artificial intelligence specifically trained on diverse skin tones and eye conditions common in African
                populations, we provide a unified tool that can help detect potential conditions early, empowering users
                to seek appropriate medical attention when needed.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">How It Works</h2>
              <p className="text-muted-foreground mb-4">
                MelËye uses advanced AI algorithms optimized for African skin tones and eye characteristics to analyze
                images. Our integrated approach allows for comprehensive screening:
              </p>
              <ol className="list-decimal pl-6 space-y-2 text-muted-foreground">
                <li>Upload a photo or take a picture using your device's camera</li>
                <li>Our AI automatically determines whether it's examining skin or eye conditions</li>
                <li>The system analyzes the image for potential signs of common conditions</li>
                <li>Receive instant feedback with recommendations for both skin and eye health</li>
                <li>Save your results for future reference and track changes over time</li>
              </ol>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Integrated Approach</h2>
              <p className="text-muted-foreground">
                MelËye uniquely combines skin and eye condition detection in a single platform. This integrated approach
                is especially valuable because many systemic health issues can manifest in both the skin and eyes. By
                analyzing both, our system can provide more comprehensive health insights and detect patterns that might
                be missed when looking at either in isolation. This is particularly important for conditions like
                diabetes, autoimmune disorders, and nutritional deficiencies that can affect both skin and eye health.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Addressing AI Bias</h2>
              <p className="text-muted-foreground">
                Most medical AI systems are trained predominantly on lighter skin tones, leading to less accurate
                results for people with darker skin. MelËye is different. We've built our technology from the ground up
                to recognize and accurately analyze conditions across the full spectrum of African skin tones and eye
                characteristics. Our integrated approach ensures that users receive relevant and accurate health
                insights for both skin and eye conditions, regardless of their skin tone.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Important Disclaimer</h2>
              <div className="bg-muted p-4 rounded-lg">
                <p className="text-sm">
                  MelËye is designed to be an informational tool only and is not intended to replace professional
                  medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified
                  health provider with any questions you may have regarding a medical condition. Never disregard
                  professional medical advice or delay in seeking it because of something you have read or seen on this
                  app.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Privacy & Security</h2>
              <p className="text-muted-foreground">
                We take your privacy seriously. All images are processed locally on your device and are not permanently
                stored on our servers. Your scan history is saved only on your device and can be deleted at any time.
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
