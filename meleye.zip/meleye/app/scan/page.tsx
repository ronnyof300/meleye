import type { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ScanForm } from "@/components/scan-form"

export const metadata: Metadata = {
  title: "New Scan - HealthScan",
  description: "Upload or capture an image for AI health screening",
}

export default function ScanPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8 md:py-12">
        <div className="mx-auto max-w-2xl">
          <h1 className="text-2xl font-bold mb-6 text-center">New Health Scan</h1>
          <ScanForm />
        </div>
      </main>
      <Footer />
    </div>
  )
}
