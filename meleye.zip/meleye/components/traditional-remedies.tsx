import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"

type TraditionalRemediesProps = {
  condition: string
}

export function TraditionalRemedies({ condition }: TraditionalRemediesProps) {
  // Get remedies based on condition
  const remedies = getRemediesForCondition(condition)

  if (remedies.length === 0) {
    return null
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Traditional Approaches</CardTitle>
        <CardDescription>Information about traditional remedies that may complement medical treatment</CardDescription>
      </CardHeader>
      <CardContent>
        <Alert className="mb-4">
          <InfoIcon className="h-4 w-4" />
          <AlertTitle>Important Note</AlertTitle>
          <AlertDescription>
            These traditional approaches should complement, not replace, professional medical advice.
          </AlertDescription>
        </Alert>

        <Accordion type="single" collapsible className="w-full">
          {remedies.map((remedy, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger>{remedy.name}</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2">
                  <p>{remedy.description}</p>
                  <p className="text-sm text-muted-foreground">Region: {remedy.region}</p>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  )
}

type Remedy = {
  name: string
  description: string
  region: string
}

function getRemediesForCondition(condition: string): Remedy[] {
  const remedyDatabase: Record<string, Remedy[]> = {
    "Dry Eye Syndrome": [
      {
        name: "Aloe Vera Gel",
        description:
          "Fresh aloe vera gel applied around the eyes (not in the eyes) can help soothe inflammation and dryness.",
        region: "Pan-African",
      },
      {
        name: "Hibiscus Tea Compress",
        description: "Cooled hibiscus tea can be used as a compress to reduce inflammation and soothe dry eyes.",
        region: "West Africa",
      },
    ],
    Conjunctivitis: [
      {
        name: "Euphorbia Hirta",
        description:
          "A diluted infusion of Euphorbia Hirta (Asthma Plant) leaves has been traditionally used to wash infected eyes.",
        region: "East Africa",
      },
    ],
    Eczema: [
      {
        name: "Shea Butter Application",
        description: "Raw, unrefined shea butter is traditionally used to moisturize and soothe eczema-affected skin.",
        region: "West Africa",
      },
      {
        name: "Neem Oil",
        description: "Neem oil has anti-inflammatory and antibacterial properties that may help with eczema symptoms.",
        region: "East Africa",
      },
    ],
    Acne: [
      {
        name: "Clay Masks",
        description:
          "Traditional African clay masks using local clay types can help absorb excess oil and reduce inflammation.",
        region: "North Africa",
      },
    ],
    Psoriasis: [
      {
        name: "Baobab Oil",
        description: "Baobab oil is rich in vitamins and has been used to moisturize and soothe psoriasis patches.",
        region: "Southern Africa",
      },
    ],
    Vitiligo: [
      {
        name: "Black Seed Oil",
        description:
          "Black seed oil (Nigella sativa) has been traditionally used to help with repigmentation in vitiligo.",
        region: "North Africa",
      },
    ],
  }

  return remedyDatabase[condition] || []
}
