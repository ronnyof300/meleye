import type { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export const metadata: Metadata = {
  title: "Privacy Policy - HealthScan",
  description: "HealthScan privacy policy and data handling practices",
}

export default function PrivacyPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8 md:py-12">
        <div className="mx-auto max-w-3xl">
          <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>

          <div className="space-y-6">
            <section>
              <h2 className="text-xl font-semibold mb-3">Introduction</h2>
              <p className="text-muted-foreground">
                This Privacy Policy explains how HealthScan collects, uses, and protects your information when you use
                our application. We are committed to ensuring that your privacy is protected.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">Information We Collect</h2>
              <p className="text-muted-foreground mb-4">HealthScan collects the following information:</p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                <li>Images you upload or capture for analysis</li>
                <li>Analysis results generated from these images</li>
                <li>Timestamps of when scans were performed</li>
              </ul>
              <p className="text-muted-foreground mt-4">
                All of this information is stored locally on your device and is not transmitted to our servers for
                storage.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">How We Use Your Information</h2>
              <p className="text-muted-foreground mb-4">The information collected is used solely for:</p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                <li>Providing you with analysis results</li>
                <li>Maintaining a history of your previous scans</li>
                <li>Improving our AI algorithms and application functionality</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">Data Storage and Security</h2>
              <p className="text-muted-foreground">
                All your scan data is stored locally on your device using your browser's localStorage. This data remains
                on your device and is not transmitted to our servers. You can delete this data at any time by clearing
                your browser data or using the delete function within the application.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">Third-Party Services</h2>
              <p className="text-muted-foreground">
                HealthScan does not share your data with any third-party services or partners.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">Changes to This Policy</h2>
              <p className="text-muted-foreground">
                We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new
                Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">Contact Us</h2>
              <p className="text-muted-foreground">
                If you have any questions about this Privacy Policy, please contact us at
                privacy@healthscan.example.com.
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
