import * as tf from "@tensorflow/tfjs"

// Cache for loaded models
const modelCache: Record<string, tf.LayersModel> = {}

// Load a model from a URL
export async function loadModel(modelType: "eye" | "skin"): Promise<tf.LayersModel> {
  if (modelCache[modelType]) {
    return modelCache[modelType]
  }

  // Replace these URLs with your actual model URLs
  const modelUrl =
    modelType === "eye"
      ? "https://your-model-hosting.com/eye-model/model.json"
      : "https://your-model-hosting.com/skin-model/model.json"

  try {
    const model = await tf.loadLayersModel(modelUrl)
    modelCache[modelType] = model
    return model
  } catch (error) {
    console.error(`Error loading ${modelType} model:`, error)
    throw new Error(`Failed to load ${modelType} model`)
  }
}

// Class labels for each model
export const eyeConditionLabels = [
  "Normal",
  "Cataract",
  "Glaucoma",
  "Diabetic Retinopathy",
  "Age-related Macular Degeneration",
  "Conjunctivitis",
  "Dry Eye Syndrome",
  "Blepharitis",
]

export const skinConditionLabels = [
  "Normal",
  "Acne",
  "Eczema",
  "Psoriasis",
  "Rosacea",
  "Melanoma",
  "Basal Cell Carcinoma",
  "Squamous Cell Carcinoma",
  "Hives",
  "Contact Dermatitis",
]

// Preprocess image for model input
export function preprocessImage(imageElement: HTMLImageElement, modelType: "eye" | "skin"): tf.Tensor {
  // Create a tensor from the image
  const tensor = tf.browser
    .fromPixels(imageElement)
    .resizeNearestNeighbor([224, 224]) // Resize to model input size
    .toFloat()
    .div(tf.scalar(255.0)) // Normalize to [0,1]
    .expandDims(0) // Add batch dimension

  return tensor
}
