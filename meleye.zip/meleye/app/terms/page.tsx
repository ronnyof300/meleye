import type { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export const metadata: Metadata = {
  title: "Terms of Service - HealthScan",
  description: "HealthScan terms of service and usage agreement",
}

export default function TermsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8 md:py-12">
        <div className="mx-auto max-w-3xl">
          <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>

          <div className="space-y-6">
            <section>
              <h2 className="text-xl font-semibold mb-3">1. Acceptance of Terms</h2>
              <p className="text-muted-foreground">
                By accessing or using HealthScan, you agree to be bound by these Terms of Service. If you do not agree
                to these terms, please do not use the application.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">2. Description of Service</h2>
              <p className="text-muted-foreground">
                HealthScan is an AI-powered application designed to provide preliminary screening for potential eye and
                skin conditions. The service allows users to upload or capture images and receive automated analysis
                results.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">3. Medical Disclaimer</h2>
              <p className="text-muted-foreground">
                HealthScan is not a substitute for professional medical advice, diagnosis, or treatment. The analysis
                provided by our application is for informational purposes only and should not be considered a medical
                diagnosis. Always seek the advice of your physician or other qualified health provider with any
                questions you may have regarding a medical condition.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">4. User Responsibilities</h2>
              <p className="text-muted-foreground mb-4">As a user of HealthScan, you agree to:</p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                <li>Provide accurate information and images</li>
                <li>Not use the service for any illegal or unauthorized purpose</li>
                <li>Not attempt to reverse-engineer or compromise the security of the application</li>
                <li>Understand that the analysis results are not a definitive medical diagnosis</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">5. Limitation of Liability</h2>
              <p className="text-muted-foreground">
                HealthScan and its creators shall not be liable for any direct, indirect, incidental, special,
                consequential, or exemplary damages resulting from your use of the service or any decisions made based
                on the information provided by the application.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">6. Changes to Terms</h2>
              <p className="text-muted-foreground">
                We reserve the right to modify these Terms of Service at any time. We will notify users of any
                significant changes by posting the new Terms of Service on this page. Your continued use of the
                application after any changes constitutes your acceptance of the new Terms of Service.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">7. Governing Law</h2>
              <p className="text-muted-foreground">
                These Terms of Service shall be governed by and construed in accordance with the laws of the
                jurisdiction in which the application creators operate, without regard to its conflict of law
                provisions.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">8. Contact</h2>
              <p className="text-muted-foreground">
                If you have any questions about these Terms of Service, please contact us at
                terms@healthscan.example.com.
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
