import type { Metadata } from "next"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

export const metadata: Metadata = {
  title: "Health Education - MelËye",
  description: "Learn about common eye and skin conditions in African contexts",
}

export default function EducationPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8 md:py-12">
        <div className="mx-auto max-w-4xl">
          <h1 className="text-3xl font-bold mb-6">Health Education</h1>

          <Tabs defaultValue="eye" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="eye">Eye Health</TabsTrigger>
              <TabsTrigger value="skin">Skin Health</TabsTrigger>
            </TabsList>

            <TabsContent value="eye" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Understanding Eye Health in African Contexts</CardTitle>
                  <CardDescription>Learn about common eye conditions affecting African populations</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p>
                    Eye health in Africa presents unique challenges due to environmental factors, limited access to
                    healthcare, and genetic predispositions. Understanding these conditions can help with early
                    detection and treatment.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                    {eyeConditions.map((condition) => (
                      <Link href={`/education/eye/${condition.slug}`} key={condition.slug} className="block">
                        <Card className="h-full hover:bg-muted/50 transition-colors">
                          <CardHeader className="pb-2">
                            <CardTitle className="text-lg">{condition.title}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm text-muted-foreground">{condition.description}</p>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Prevention Tips</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Protect your eyes from excessive sun exposure with sunglasses that block UV rays</li>
                    <li>Maintain good hygiene to prevent infections, especially in dusty environments</li>
                    <li>Stay hydrated to prevent dry eyes, particularly in arid regions</li>
                    <li>Eat a balanced diet rich in vitamins A, C, and E</li>
                    <li>Get regular eye check-ups, especially if you have a family history of eye conditions</li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="skin" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Understanding Skin Health for African Skin Types</CardTitle>
                  <CardDescription>
                    Learn about common skin conditions affecting people with darker skin tones
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p>
                    African skin types have unique characteristics that affect how certain skin conditions present and
                    should be treated. Understanding these differences is crucial for proper diagnosis and care.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                    {skinConditions.map((condition) => (
                      <Link href={`/education/skin/${condition.slug}`} key={condition.slug} className="block">
                        <Card className="h-full hover:bg-muted/50 transition-colors">
                          <CardHeader className="pb-2">
                            <CardTitle className="text-lg">{condition.title}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm text-muted-foreground">{condition.description}</p>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Skin Care Tips for African Skin</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>
                      Use sunscreen daily - melanin provides some protection but doesn't block all harmful UV rays
                    </li>
                    <li>Keep skin moisturized to prevent ashiness, especially in dry climates</li>
                    <li>Be cautious with chemical treatments that can cause hyperpigmentation</li>
                    <li>Use gentle cleansers that don't strip natural oils</li>
                    <li>Monitor changes in moles and skin marks, as skin cancer can affect all skin types</li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  )
}

const eyeConditions = [
  {
    title: "Trachoma",
    slug: "trachoma",
    description: "A bacterial infection common in parts of Africa that can lead to blindness if untreated.",
  },
  {
    title: "River Blindness",
    slug: "river-blindness",
    description:
      "Caused by parasitic worms spread by blackfly bites near rivers, leading to severe itching and potential blindness.",
  },
  {
    title: "Cataracts",
    slug: "cataracts",
    description: "Clouding of the eye's lens that commonly affects older adults and can be accelerated by UV exposure.",
  },
  {
    title: "Glaucoma",
    slug: "glaucoma",
    description:
      "A group of eye conditions that damage the optic nerve, with higher prevalence and earlier onset in African populations.",
  },
]

const skinConditions = [
  {
    title: "Keloids",
    slug: "keloids",
    description:
      "Raised scars that are more common in people with darker skin tones, forming when too much collagen is produced during healing.",
  },
  {
    title: "Vitiligo",
    slug: "vitiligo",
    description:
      "Loss of skin color in patches that is more noticeable on darker skin and may cause emotional distress.",
  },
  {
    title: "Melasma",
    slug: "melasma",
    description:
      "Hyperpigmentation that appears as brown or gray-brown patches, often triggered by sun exposure and hormonal changes.",
  },
  {
    title: "Dermatosis Papulosa Nigra",
    slug: "dpn",
    description:
      "Small, benign skin growths that commonly appear on the face and are more prevalent in people with darker skin.",
  },
]
