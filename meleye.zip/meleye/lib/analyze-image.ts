import type * as tf from "@tensorflow/tfjs"
import { loadModel, preprocessImage, eyeConditionLabels, skinConditionLabels } from "./model-loader"

export type AnalysisResult = {
  condition: string
  confidence: number
  severity: "low" | "medium" | "high"
  recommendation: string
  details: string
  type: "eye" | "skin" | "unknown"
}

// Function to determine if an image is of an eye or skin
async function classifyImageType(imageElement: HTMLImageElement, forcedType?: "eye" | "skin"): Promise<"eye" | "skin"> {
  // If type is forced by user selection, return that
  if (forcedType === "eye" || forcedType === "skin") {
    return forcedType
  }

  // In a real implementation, you would use a classifier model
  // For now, we'll use a simple heuristic based on image characteristics

  // Create a canvas to analyze the image
  const canvas = document.createElement("canvas")
  const ctx = canvas.getContext("2d")
  canvas.width = imageElement.width
  canvas.height = imageElement.height
  ctx?.drawImage(imageElement, 0, 0)

  // Get image data
  const imageData = ctx?.getImageData(0, 0, canvas.width, canvas.height)
  const data = imageData?.data

  if (!data) return Math.random() > 0.5 ? "eye" : "skin"

  // Simple heuristic: count red pixels (might indicate eye redness)
  // and analyze image shape/characteristics
  let redPixels = 0
  let darkPixels = 0
  const totalPixels = data.length / 4

  for (let i = 0; i < data.length; i += 4) {
    // Red dominant pixels (potential eye vessels)
    if (data[i] > 150 && data[i + 1] < 100 && data[i + 2] < 100) {
      redPixels++
    }

    // Dark pixels (potential pupil/iris)
    if (data[i] < 60 && data[i + 1] < 60 && data[i + 2] < 60) {
      darkPixels++
    }
  }

  // Calculate circular shape probability (eyes tend to have circular shapes)
  // This is a simplified approach - in a real app, use computer vision
  const redRatio = redPixels / totalPixels
  const darkRatio = darkPixels / totalPixels

  // If more than 5% of pixels are red or there's a significant dark center (pupil)
  // classify as eye
  return redRatio > 0.05 || darkRatio > 0.1 ? "eye" : "skin"
}

export async function analyzeImage(formData: FormData): Promise<AnalysisResult> {
  try {
    // Get the image file from FormData
    const imageFile = formData.get("image") as File
    if (!imageFile) {
      throw new Error("No image file provided")
    }

    // Get the scan type if specified
    const scanType = formData.get("scanType") as "auto" | "skin" | "eye" | null
    const forcedType = scanType === "auto" ? undefined : (scanType as "eye" | "skin" | undefined)

    // Create an image element from the file
    const imageUrl = URL.createObjectURL(imageFile)
    const imageElement = new Image()

    // Wait for the image to load
    await new Promise((resolve, reject) => {
      imageElement.onload = resolve
      imageElement.onerror = reject
      imageElement.src = imageUrl
    })

    // Determine if it's an eye or skin image
    const imageType = await classifyImageType(imageElement, forcedType)

    // Load the appropriate model
    try {
      const model = await loadModel(imageType)

      // Preprocess the image
      const tensor = preprocessImage(imageElement, imageType)

      // Run inference
      const predictions = (await model.predict(tensor)) as tf.Tensor
      const probabilities = await predictions.data()

      // Get the index of the highest probability
      let maxProbIndex = 0
      let maxProb = 0
      for (let i = 0; i < probabilities.length; i++) {
        if (probabilities[i] > maxProb) {
          maxProb = probabilities[i]
          maxProbIndex = i
        }
      }

      // Clean up tensors
      tensor.dispose()
      predictions.dispose()

      // Get the condition label
      const conditionLabel = imageType === "eye" ? eyeConditionLabels[maxProbIndex] : skinConditionLabels[maxProbIndex]

      // Get the full condition details from our database
      const conditionsDatabase = imageType === "eye" ? eyeConditions : skinConditions
      const matchedCondition = conditionsDatabase.find((c) => c.condition === conditionLabel)

      if (matchedCondition) {
        return {
          ...matchedCondition,
          confidence: maxProb,
        }
      }

      // Fallback if no match found
      return {
        condition: conditionLabel,
        confidence: maxProb,
        severity: maxProb > 0.8 ? "high" : maxProb > 0.6 ? "medium" : "low",
        recommendation: "Please consult a healthcare professional for proper diagnosis.",
        details: "Our system detected potential signs of this condition. Further examination is recommended.",
        type: imageType,
      }
    } catch (error) {
      console.error("Model inference error:", error)

      // Fallback to mock analysis if model fails
      const conditions = imageType === "eye" ? eyeConditions : skinConditions
      return conditions[Math.floor(Math.random() * conditions.length)]
    } finally {
      // Clean up the object URL
      URL.revokeObjectURL(imageUrl)
    }
  } catch (error) {
    console.error("Analysis error:", error)

    // Return a generic error result
    return {
      condition: "Analysis Error",
      confidence: 0,
      severity: "medium",
      recommendation: "Please try again with a clearer image.",
      details:
        "We encountered an error while analyzing your image. This could be due to image quality or format issues.",
      type: "unknown",
    }
  }
}

// Create a database of conditions with detailed information
export const eyeConditions = [
  {
    condition: "Normal",
    confidence: 0.95,
    severity: "low" as const,
    recommendation: "Continue regular eye check-ups.",
    details:
      "No significant eye conditions detected. Maintain good eye health with regular breaks from screens and proper lighting.",
    type: "eye" as const,
  },
  {
    condition: "Dry Eye Syndrome",
    confidence: 0.87,
    severity: "medium",
    recommendation: "Consult an ophthalmologist for proper diagnosis and treatment.",
    details:
      "Symptoms may include redness, irritation, and a gritty feeling in the eyes. Consider using artificial tears and avoiding prolonged screen time.",
    type: "eye",
  },
  {
    condition: "Conjunctivitis",
    confidence: 0.92,
    severity: "medium",
    recommendation: "Consult a doctor for proper diagnosis and treatment.",
    details:
      "Also known as pink eye, this condition causes inflammation of the conjunctiva. Avoid touching your eyes and wash hands frequently.",
    type: "eye",
  },
  {
    condition: "Cataract Early Signs",
    confidence: 0.72,
    severity: "medium",
    recommendation: "Schedule an appointment with an ophthalmologist for a comprehensive eye exam.",
    details:
      "Early signs may include cloudy vision, difficulty seeing at night, and increased sensitivity to light. Regular eye exams are important for early detection.",
    type: "eye",
  },
  {
    condition: "Glaucoma Indicators",
    confidence: 0.68,
    severity: "high",
    recommendation: "Seek immediate consultation with an ophthalmologist.",
    details:
      "Potential indicators include eye redness, halos around lights, vision loss, and eye pain. Early detection is crucial to prevent vision loss.",
    type: "eye",
  },
  {
    condition: "Blepharitis",
    confidence: 0.81,
    severity: "low",
    recommendation: "Practice good eyelid hygiene and consider consulting an eye doctor.",
    details:
      "Inflammation of the eyelids causing redness, irritation, and dandruff-like scales on eyelashes. Warm compresses and gentle eyelid cleaning may help.",
    type: "eye",
  },
  {
    condition: "Subconjunctival Hemorrhage",
    confidence: 0.89,
    severity: "low",
    recommendation: "Usually resolves on its own, but consult a doctor if it persists.",
    details:
      "A broken blood vessel in the eye causing a bright red patch. Usually harmless and caused by straining or minor trauma.",
    type: "eye",
  },
  {
    condition: "Pterygium",
    confidence: 0.75,
    severity: "low",
    recommendation: "Use artificial tears and consult an ophthalmologist if it affects vision.",
    details:
      "A growth of tissue on the conjunctiva that may extend to the cornea. Often caused by UV exposure and dry environments.",
    type: "eye",
  },
  {
    condition: "Diabetic Retinopathy Signs",
    confidence: 0.71,
    severity: "high",
    recommendation: "Urgent consultation with an ophthalmologist is recommended.",
    details:
      "Diabetes can damage blood vessels in the retina, potentially leading to vision loss. Regular eye exams are essential for diabetic patients.",
    type: "eye",
  },
  {
    condition: "Trachoma",
    confidence: 0.83,
    severity: "high",
    recommendation: "Seek medical attention as soon as possible.",
    details:
      "Trachoma is a bacterial infection common in parts of Africa that can lead to blindness if untreated. Symptoms include eye pain, light sensitivity, and discharge.",
    type: "eye",
  },
  {
    condition: "River Blindness Signs",
    confidence: 0.76,
    severity: "high",
    recommendation: "Consult a healthcare provider immediately.",
    details:
      "Onchocerciasis (river blindness) is caused by parasitic worms spread by blackfly bites near rivers. Early detection and treatment can prevent vision loss.",
    type: "eye",
  },
]

export const skinConditions = [
  {
    condition: "Normal",
    confidence: 0.95,
    severity: "low" as const,
    recommendation: "Continue regular skin care routine.",
    details:
      "No significant skin conditions detected. Maintain good skin health with proper hydration and sun protection.",
    type: "skin" as const,
  },
  {
    condition: "Eczema",
    confidence: 0.85,
    severity: "medium",
    recommendation: "Consult a dermatologist for proper diagnosis and treatment.",
    details:
      "Keep the affected area moisturized and avoid known triggers. Over-the-counter hydrocortisone cream may provide temporary relief.",
    type: "skin",
  },
  {
    condition: "Acne",
    confidence: 0.94,
    severity: "low",
    recommendation: "Consider over-the-counter treatments with benzoyl peroxide or salicylic acid.",
    details: "Maintain a consistent skincare routine. If severe, consult a dermatologist for prescription treatments.",
    type: "skin",
  },
  {
    condition: "Psoriasis",
    confidence: 0.78,
    severity: "high",
    recommendation: "Consult a dermatologist as soon as possible for proper diagnosis and treatment.",
    details:
      "This chronic condition causes rapid skin cell buildup, resulting in scaly patches. Treatment options include topical treatments, light therapy, and oral medications.",
    type: "skin",
  },
  {
    condition: "Rosacea",
    confidence: 0.82,
    severity: "medium",
    recommendation: "Consult a dermatologist for diagnosis and treatment options.",
    details:
      "A chronic skin condition causing facial redness, visible blood vessels, and sometimes small red bumps. Avoid triggers like spicy foods, alcohol, and extreme temperatures.",
    type: "skin",
  },
  {
    condition: "Contact Dermatitis",
    confidence: 0.88,
    severity: "medium",
    recommendation: "Identify and avoid the irritant. Consult a dermatologist if severe.",
    details:
      "A red, itchy rash caused by direct contact with a substance or an allergic reaction. Calamine lotion or hydrocortisone cream may provide relief.",
    type: "skin",
  },
  {
    condition: "Melanoma Warning Signs",
    confidence: 0.65,
    severity: "high",
    recommendation: "Seek immediate consultation with a dermatologist.",
    details:
      "Potential indicators of skin cancer include asymmetrical moles, irregular borders, uneven color, diameter larger than 6mm, or evolving appearance.",
    type: "skin",
  },
  {
    condition: "Fungal Infection",
    confidence: 0.79,
    severity: "medium",
    recommendation: "Use over-the-counter antifungal treatments or consult a doctor.",
    details:
      "Common fungal infections include athlete's foot, ringworm, and yeast infections. Keep the affected area clean and dry.",
    type: "skin",
  },
  {
    condition: "Hives",
    confidence: 0.86,
    severity: "medium",
    recommendation: "Take antihistamines and consult a doctor if severe or persistent.",
    details:
      "Raised, itchy welts that may be triggered by allergies, stress, or infections. Cool compresses may help reduce itching and swelling.",
    type: "skin",
  },
  {
    condition: "Shingles",
    confidence: 0.77,
    severity: "high",
    recommendation: "Seek medical attention promptly for antiviral treatment.",
    details: "A painful rash caused by the varicella-zoster virus. Early treatment can reduce pain and complications.",
    type: "skin",
  },
  {
    condition: "Keloid Formation",
    confidence: 0.88,
    severity: "medium",
    recommendation: "Consult a dermatologist for treatment options.",
    details:
      "Keloids are raised scars that are more common in people with darker skin tones. They form when too much collagen is produced during healing.",
    type: "skin",
  },
  {
    condition: "Vitiligo",
    confidence: 0.91,
    severity: "low",
    recommendation: "Consult a dermatologist for diagnosis and treatment options.",
    details:
      "Vitiligo causes loss of skin color in patches and is more noticeable on darker skin. While not physically harmful, it may cause emotional distress.",
    type: "skin",
  },
  {
    condition: "Albinism",
    confidence: 0.95,
    severity: "medium",
    recommendation: "Use sun protection and consult a dermatologist regularly.",
    details:
      "Albinism is a genetic condition affecting melanin production. People with albinism in Africa need special protection from sun exposure and regular skin checks.",
    type: "skin",
  },
]

// Function to get all possible conditions (useful for reference or UI)
export function getAllConditions(): AnalysisResult[] {
  return [...eyeConditions, ...skinConditions]
}
