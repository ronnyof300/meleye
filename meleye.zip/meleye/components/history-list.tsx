"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertTriangleIcon, CheckCircleIcon, InfoIcon, EyeIcon, TrashIcon } from "lucide-react"
import type { AnalysisResult } from "@/lib/analyze-image"

type ScanResult = {
  image: string
  result: AnalysisResult
  timestamp: string
}

export function HistoryList() {
  const [history, setHistory] = useState<ScanResult[]>([])
  const [selectedScan, setSelectedScan] = useState<ScanResult | null>(null)

  useEffect(() => {
    // Get scan history from localStorage
    const historyData = localStorage.getItem("scanHistory")

    if (historyData) {
      try {
        const parsedHistory = JSON.parse(historyData) as ScanResult[]
        setHistory(parsedHistory)
      } catch (error) {
        console.error("Error parsing history data:", error)
      }
    }
  }, [])

  const deleteScan = (index: number) => {
    const updatedHistory = [...history]
    updatedHistory.splice(index, 1)
    setHistory(updatedHistory)
    localStorage.setItem("scanHistory", JSON.stringify(updatedHistory))

    if (selectedScan) {
      setSelectedScan(null)
    }
  }

  const viewScanDetails = (scan: ScanResult) => {
    setSelectedScan(scan)
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "low":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "high":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "low":
        return <CheckCircleIcon className="h-5 w-5 text-green-600 dark:text-green-400" />
      case "medium":
        return <AlertTriangleIcon className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
      case "high":
        return <AlertTriangleIcon className="h-5 w-5 text-red-600 dark:text-red-400" />
      default:
        return <InfoIcon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
    }
  }

  if (history.length === 0) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p className="mb-4">You don't have any saved scans yet.</p>
          <Link href="/scan">
            <Button>Create Your First Scan</Button>
          </Link>
        </CardContent>
      </Card>
    )
  }

  if (selectedScan) {
    const { result, image, timestamp } = selectedScan
    const date = new Date(timestamp)
    const formattedDate = date.toLocaleDateString()
    const formattedTime = date.toLocaleTimeString()

    return (
      <div className="space-y-4">
        <Button variant="outline" onClick={() => setSelectedScan(null)}>
          Back to History
        </Button>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span>{result.condition}</span>
              <Badge className={getSeverityColor(result.severity)}>
                {result.severity.charAt(0).toUpperCase() + result.severity.slice(1)} Severity
              </Badge>
            </CardTitle>
            <CardDescription>
              Scan completed on {formattedDate} at {formattedTime}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <img
                  src={image || "/placeholder.svg"}
                  alt="Scanned image"
                  className="rounded-lg border object-cover w-full h-auto max-h-[300px]"
                />
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    {getSeverityIcon(result.severity)}
                    {result.condition}
                  </h3>
                  <p className="text-sm text-muted-foreground">Confidence: {(result.confidence * 100).toFixed(1)}%</p>
                </div>
                <div>
                  <h4 className="font-medium">Recommendation</h4>
                  <p className="text-sm">{result.recommendation}</p>
                </div>
                <div>
                  <h4 className="font-medium">Details</h4>
                  <p className="text-sm">{result.details}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {history.map((scan, index) => {
        const date = new Date(scan.timestamp)
        const formattedDate = date.toLocaleDateString()
        const formattedTime = date.toLocaleTimeString()

        return (
          <Card key={index}>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                {getSeverityIcon(scan.result.severity)}
                {scan.result.condition}
              </CardTitle>
              <CardDescription>
                {formattedDate} at {formattedTime}
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 shrink-0">
                  <img
                    src={scan.image || "/placeholder.svg"}
                    alt="Scan thumbnail"
                    className="w-full h-full object-cover rounded-md border"
                  />
                </div>
                <div>
                  <Badge className={getSeverityColor(scan.result.severity)}>
                    {scan.result.severity.charAt(0).toUpperCase() + scan.result.severity.slice(1)} Severity
                  </Badge>
                  <p className="text-sm mt-1 line-clamp-2">{scan.result.recommendation}</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <div className="flex gap-2 w-full">
                <Button variant="outline" size="sm" className="flex-1" onClick={() => viewScanDetails(scan)}>
                  <EyeIcon className="h-4 w-4 mr-1" />
                  View Details
                </Button>
                <Button variant="outline" size="sm" onClick={() => deleteScan(index)}>
                  <TrashIcon className="h-4 w-4" />
                  <span className="sr-only">Delete</span>
                </Button>
              </div>
            </CardFooter>
          </Card>
        )
      })}
    </div>
  )
}
