"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CameraIcon, UploadIcon, Loader2Icon, EyeIcon, ScanIcon } from "lucide-react"
import { analyzeImage } from "@/lib/analyze-image"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

export function ScanForm() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("upload")
  const [scanType, setScanType] = useState<"auto" | "skin" | "eye">("auto")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [cameraActive, setCameraActive] = useState(false)
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        setImagePreview(event.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleUploadClick = () => {
    fileInputRef.current?.click()
  }

  const startCamera = async () => {
    try {
      const constraints = {
        video: {
          facingMode: "environment",
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      }

      const stream = await navigator.mediaDevices.getUserMedia(constraints)

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setCameraStream(stream)
        setCameraActive(true)
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      alert("Unable to access camera. Please check permissions or try uploading an image instead.")
    }
  }

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop())
      setCameraStream(null)
      setCameraActive(false)
    }
  }

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current
      const canvas = canvasRef.current
      const context = canvas.getContext("2d")

      // Set canvas dimensions to match video
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      // Draw the current video frame to the canvas
      context?.drawImage(video, 0, 0, canvas.width, canvas.height)

      // Convert canvas to data URL
      const imageDataUrl = canvas.toDataURL("image/jpeg")
      setImagePreview(imageDataUrl)

      // Stop the camera
      stopCamera()
    }
  }

  const handleTabChange = (value: string) => {
    setActiveTab(value)
    setImagePreview(null)

    if (value === "camera") {
      startCamera()
    } else {
      stopCamera()
    }
  }

  const handleSubmit = async () => {
    if (!imagePreview) return

    setIsLoading(true)

    try {
      // Convert data URL to Blob
      const response = await fetch(imagePreview)
      const blob = await response.blob()

      // Create a File object from the Blob
      const file = new File([blob], "image.jpg", { type: "image/jpeg" })

      // Create FormData
      const formData = new FormData()
      formData.append("image", file)
      formData.append("scanType", scanType)

      // Call the analyze function
      const result = await analyzeImage(formData)

      // Store result in localStorage for the results page
      localStorage.setItem(
        "scanResult",
        JSON.stringify({
          image: imagePreview,
          result,
          timestamp: new Date().toISOString(),
        }),
      )

      // Navigate to results page
      router.push("/results")
    } catch (error) {
      console.error("Error analyzing image:", error)
      alert("An error occurred while analyzing the image. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardContent className="p-6">
        <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="upload">Upload Image</TabsTrigger>
            <TabsTrigger value="camera">Use Camera</TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-4">
            <div
              className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={handleUploadClick}
            >
              {imagePreview ? (
                <div className="w-full">
                  <img
                    src={imagePreview || "/placeholder.svg"}
                    alt="Preview"
                    className="max-h-[300px] mx-auto rounded-lg object-contain"
                  />
                </div>
              ) : (
                <>
                  <UploadIcon className="h-10 w-10 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground mb-1">Click to upload an image</p>
                  <p className="text-xs text-muted-foreground">Supported formats: JPG, PNG</p>
                </>
              )}
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept="image/jpeg,image/png"
                onChange={handleFileChange}
              />
            </div>
          </TabsContent>

          <TabsContent value="camera" className="space-y-4">
            <div className="border rounded-lg p-2 bg-black">
              {cameraActive ? (
                <video ref={videoRef} autoPlay playsInline className="w-full h-[300px] object-cover rounded-md" />
              ) : imagePreview ? (
                <img
                  src={imagePreview || "/placeholder.svg"}
                  alt="Captured"
                  className="max-h-[300px] w-full object-contain rounded-md"
                />
              ) : (
                <div className="h-[300px] flex items-center justify-center">
                  <CameraIcon className="h-10 w-10 text-muted-foreground" />
                </div>
              )}
              <canvas ref={canvasRef} className="hidden" />
            </div>

            {cameraActive ? (
              <Button onClick={captureImage} className="w-full">
                <CameraIcon className="mr-2 h-4 w-4" />
                Capture Photo
              </Button>
            ) : (
              <Button onClick={startCamera} className="w-full" disabled={!!imagePreview}>
                <CameraIcon className="mr-2 h-4 w-4" />
                Start Camera
              </Button>
            )}
          </TabsContent>
        </Tabs>

        {imagePreview && (
          <div className="mt-6 space-y-4">
            <div className="border rounded-lg p-4">
              <h3 className="text-sm font-medium mb-3">Scan Type</h3>
              <RadioGroup value={scanType} onValueChange={(value) => setScanType(value as "auto" | "skin" | "eye")}>
                <div className="flex flex-col space-y-2">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="auto" id="auto" />
                    <Label htmlFor="auto" className="flex items-center">
                      <ScanIcon className="h-4 w-4 mr-2" />
                      Auto-detect (Recommended)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="skin" id="skin" />
                    <Label htmlFor="skin">Skin Condition</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="eye" id="eye" />
                    <Label htmlFor="eye">
                      <EyeIcon className="h-4 w-4 mr-2 inline" />
                      Eye Condition
                    </Label>
                  </div>
                </div>
              </RadioGroup>
            </div>

            <Button onClick={handleSubmit} className="w-full" disabled={!imagePreview || isLoading}>
              {isLoading ? (
                <>
                  <Loader2Icon className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                "Analyze Image"
              )}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
