"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertTriangleIcon, CheckCircleIcon, InfoIcon, ArrowLeftIcon, SaveIcon, EyeIcon, ScanIcon } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TraditionalRemedies } from "@/components/traditional-remedies"
import { CommunityReferral } from "@/components/community-referral"
import type { AnalysisResult } from "@/lib/analyze-image"

type ScanResult = {
  image: string
  result: AnalysisResult
  timestamp: string
}

export function ResultsDisplay() {
  const router = useRouter()
  const [scanResult, setScanResult] = useState<ScanResult | null>(null)
  const [saved, setSaved] = useState(false)
  const [activeTab, setActiveTab] = useState("results")

  useEffect(() => {
    // Get the scan result from localStorage
    const resultData = localStorage.getItem("scanResult")

    if (!resultData) {
      // Redirect to scan page if no result is found
      router.push("/scan")
      return
    }

    try {
      const parsedResult = JSON.parse(resultData) as ScanResult
      setScanResult(parsedResult)
    } catch (error) {
      console.error("Error parsing scan result:", error)
      router.push("/scan")
    }
  }, [router])

  const saveToHistory = () => {
    if (!scanResult) return

    // Get existing history from localStorage
    const historyData = localStorage.getItem("scanHistory")
    let history: ScanResult[] = []

    if (historyData) {
      try {
        history = JSON.parse(historyData)
      } catch (error) {
        console.error("Error parsing history data:", error)
      }
    }

    // Add current scan to history
    history.unshift(scanResult)

    // Save back to localStorage
    localStorage.setItem("scanHistory", JSON.stringify(history))
    setSaved(true)
  }

  if (!scanResult) {
    return (
      <Card>
        <CardContent className="p-6 flex justify-center items-center">
          <p>Loading results...</p>
        </CardContent>
      </Card>
    )
  }

  const { result, image, timestamp } = scanResult
  const date = new Date(timestamp)
  const formattedDate = date.toLocaleDateString()
  const formattedTime = date.toLocaleTimeString()

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "low":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "high":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "low":
        return <CheckCircleIcon className="h-5 w-5 text-green-600 dark:text-green-400" />
      case "medium":
        return <AlertTriangleIcon className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
      case "high":
        return <AlertTriangleIcon className="h-5 w-5 text-red-600 dark:text-red-400" />
      default:
        return <InfoIcon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
    }
  }

  const getConditionTypeIcon = (type: string) => {
    switch (type) {
      case "eye":
        return <EyeIcon className="h-5 w-5 mr-1" />
      case "skin":
        return <ScanIcon className="h-5 w-5 mr-1" />
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span>Analysis Results</span>
            <Badge className={getSeverityColor(result.severity)}>
              {result.severity.charAt(0).toUpperCase() + result.severity.slice(1)} Severity
            </Badge>
          </CardTitle>
          <CardDescription>
            Scan completed on {formattedDate} at {formattedTime}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <img
                src={image || "/placeholder.svg"}
                alt="Scanned image"
                className="rounded-lg border object-cover w-full h-auto max-h-[300px]"
              />
            </div>
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  {getSeverityIcon(result.severity)}
                  <div className="flex items-center">
                    {getConditionTypeIcon(result.type)}
                    {result.condition}
                  </div>
                </h3>
                <p className="text-sm text-muted-foreground">Confidence: {(result.confidence * 100).toFixed(1)}%</p>
              </div>
              <div>
                <h4 className="font-medium">Recommendation</h4>
                <p className="text-sm">{result.recommendation}</p>
              </div>
              <div>
                <h4 className="font-medium">Details</h4>
                <p className="text-sm">{result.details}</p>
              </div>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="results">Results</TabsTrigger>
              <TabsTrigger value="traditional">Traditional Approaches</TabsTrigger>
              <TabsTrigger value="referral">Get Help</TabsTrigger>
            </TabsList>

            <TabsContent value="results" className="mt-4">
              <div className="bg-muted p-4 rounded-lg">
                <h3 className="font-medium mb-2">Disclaimer</h3>
                <p className="text-sm text-muted-foreground">
                  This analysis is provided for informational purposes only and should not be considered a medical
                  diagnosis. Always consult with a healthcare professional for proper evaluation and treatment.
                </p>
              </div>
            </TabsContent>

            <TabsContent value="traditional" className="mt-4">
              <TraditionalRemedies condition={result.condition} />
            </TabsContent>

            <TabsContent value="referral" className="mt-4">
              <CommunityReferral condition={result.condition} severity={result.severity} />
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row gap-3">
          <Link href="/scan" className="w-full sm:w-auto">
            <Button variant="outline" className="w-full">
              <ArrowLeftIcon className="mr-2 h-4 w-4" />
              New Scan
            </Button>
          </Link>
          <Button onClick={saveToHistory} className="w-full sm:w-auto" disabled={saved}>
            <SaveIcon className="mr-2 h-4 w-4" />
            {saved ? "Saved to History" : "Save to History"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
